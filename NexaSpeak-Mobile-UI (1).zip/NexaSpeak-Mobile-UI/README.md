# NexaSpeak AI — Mobile-first UI/UX Prototype

A React + Vite frontend prototype for NexaSpeak AI. This phase focuses on the interface only; it does not connect Django, an LLM, Whisper, RAG, or KittenTTS.

## UI features
- Name-based demo entry screen (not secure authentication)
- Responsive mobile-first layout with dark navy, violet, and cyan gradients
- Home, AI Chat, History, and Knowledge views
- New chat and session-only conversation history
- Message composer with Enter-to-send (Shift+Enter for a new line)
- Browser speech recognition where supported (Chrome is recommended; microphone permission required)
- Transcript preview/editing before sending
- File picker for PDF/TXT/Markdown (UI-only; files are not processed or uploaded)
- Light/dark appearance toggle
- Copy-response control and prototype voice playback notice

## Run locally
Requires Node.js 18+.

```bash
npm install
npm run dev
```

For a production build:

```bash
npm run build
npm run preview
```

## Deploy
Deploy this as a **Vite/React static frontend** (for example, on Vercel or Netlify). It is not a Streamlit app; do not deploy it as `app.py` on Streamlit Community Cloud. If deploying on a static host, use build command `npm run build` and output directory `dist`.

## Prototype limitations
- Demo entry is not secure login/authentication.
- AI replies are placeholder text.
- Chat history and selected file names remain in in-memory React state only.
- Files are not parsed or uploaded.
- Speech input uses the browser Web Speech API when available; support varies by browser and secure context.
- Text-to-speech, Whisper, RAG, KittenTTS, Django APIs, and persistent storage are not connected.
